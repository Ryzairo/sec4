# wp3-2024-starter
Template voor WP3 opdracht "Accessibility Hub". Vul dit document aan zoals beschreven in eisen rondom opleveren (zie ook de [opdracht](CASUS.md)) 

DATABASE ERD

![image](https://github.com/Rac-Software-Development/wp3-2024-rest-1d3-d3vs/assets/143651714/5af17746-4feb-4fd2-9185-cf13cc9fa93b)
